import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import sqlite3
from algo_des_db import AlgorithmDescriptionDB


class EducationalPanel(tk.Toplevel):
    def __init__(self, master, algorithm_name):
        super().__init__(master)
        self.title(f"{algorithm_name} Algorithm Description")
        self.geometry(self.calculate_position())  # Position the window
        self.resizable(False, False)
        self.attributes("-topmost", True)  # Ensure it stays on top
        
        # Fetch algorithm details
        self.db = AlgorithmDescriptionDB()
        algorithm_info = self.db.get_algorithm_info(algorithm_name)

        if not algorithm_info:
            algorithm_info = {
                "definition": "No information available.",
                "working": "",
                "complexity": "",
                "pseudocode": ""
            }

        self.configure(bg="white")

        # Create a canvas with a scrollbar
        container = tk.Frame(self, bg="white")
        container.pack(fill="both", expand=True)

        canvas = tk.Canvas(container, bg="white", highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg="white")  # The frame inside the canvas

        # Connect the frame to the canvas
        scroll_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Pack canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Enable scrolling with the mouse wheel
        self.bind("<Enter>", lambda e: self.bind_all("<MouseWheel>", self._on_mousewheel))
        self.bind("<Leave>", lambda e: self.unbind_all("<MouseWheel>"))

        # Function to add section titles
        def add_title(frame, text):
            label = tk.Label(frame, text=text, font=("Arial", 18, "bold", "underline"), bg="white")
            label.pack(anchor="w", pady=(5, 2))

        # Function to add section text
        def add_text(frame, text):
            label = tk.Label(frame, text=text, font=("Arial", 14), wraplength=350, justify="left", bg="white")
            label.pack(anchor="w", pady=(0, 5))

        # Add formatted content
        add_title(scroll_frame, "Definition:")
        add_text(scroll_frame, algorithm_info["definition"])

        add_title(scroll_frame, "Working:")
        add_text(scroll_frame, algorithm_info["working"])

        add_title(scroll_frame, "Time Complexity:")
        add_text(scroll_frame, algorithm_info["complexity"])

        add_title(scroll_frame, "Pseudocode:")
        add_text(scroll_frame, algorithm_info["pseudocode"])

        # Add relevant image
        # self.add_algorithm_image(scroll_frame, algorithm_name)

        # Save references
        self.canvas = canvas
        self.scroll_frame = scroll_frame

    def calculate_position(self):
        """Calculate the position for the window to be in the middle-right of the screen."""
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()

        window_width = 500  # Width of the description panel
        window_height = 720  # Height of the description panel

        x_position = screen_width - window_width + 360  # 20 pixels from right
        y_position = (screen_height // 2) - (window_height // 3)  # Centered vertically

        return f"{window_width}x{window_height}+{x_position}+{y_position}"

    # def add_algorithm_image(self, frame, algorithm_name):
    #     """Load and display an image relevant to the algorithm."""
    #     image_path = f"images/{algorithm_name.lower().replace(' ', '_')}.png"

    #     try:
    #         img = Image.open(image_path)
    #         img = img.resize((350, 200), Image.LANCZOS)
    #         img_tk = ImageTk.PhotoImage(img)

    #         img_label = tk.Label(frame, image=img_tk, bg="white")
    #         img_label.image = img_tk  # Keep a reference to avoid garbage collection
    #         img_label.pack(pady=10)
    #     except Exception as e:
    #         print(f"Image not found for {algorithm_name}: {e}")

    def _on_mousewheel(self, event):
        """Enable scrolling with the mouse wheel."""
        self.canvas.yview_scroll(-1 * (event.delta // 120), "units")

